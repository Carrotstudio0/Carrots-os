CarrotOS 1.0 - Professional Linux Distribution
=========================================================

Welcome to CarrotOS 1.0!

BOOT:
- Burn ISO to USB or CD
- Boot and install

REQUIREMENTS:
- 2GB RAM
- 10GB disk
- x86-64 CPU

VERSION: 1.0.0
BUILD DATE: 2026-02-25
ARCH: x86-64

Visit: https://carrotos.dev
